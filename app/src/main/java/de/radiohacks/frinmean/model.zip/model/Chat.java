package de.radiohacks.frinmean.model;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 * Created by thomas on 05.09.14.
 */
//    @Default(DefaultType.FIELD)
//    @Order(elements = {"chatname", "chatID", "owningUsername", "owningUserID"})
@Root(name = "Chat")
public class Chat {

    @Element(name = "Chatname", required = true)
    protected String chatname;
    @Element(name = "ChatID", required = true)
    protected int chatID;
    @Element(name = "OwningUser", required = true)
    protected OwningUser owningUser;

    public Chat() {

    }

    public String getChatname() {
        return chatname;
    }

    public void setChatname(String value) {
        this.chatname = value;
    }

    public int getChatID() {
        return chatID;
    }

    public void setChatID(int value) {
        this.chatID = value;
    }

    public OwningUser getOwningUser() {
        return owningUser;
    }

    public void setOwningUser(OwningUser value) {
        this.owningUser = value;
    }
}
