package de.radiohacks.frinmean.model;

import org.simpleframework.xml.Default;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Root;

/**
 * Created by thomas on 06.09.14.
 */

/**
 * <p/>
 * Java class for anonymous complex type.
 * <p/>
 * <p/>
 * The following schema fragment specifies the expected content
 * contained within this class.
 * <p/>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OwningUserName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OwningUserID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
//@Default(DefaultType.FIELD)
//@Order(elements = {"owningUserName", "owningUserID"})
@Root(name = "OwningUser")
public class OwningUser {

    @Element(name = "OwningUserName", required = true)
    protected String owningUserName;
    @Element(required = true, name = "OwningUserID")
    protected int owningUserID;

    public String getOwningUserName() {
        return owningUserName;
    }

    public void setOwningUserName(String value) {
        this.owningUserName = value;
    }

    public int getOwningUserID() {
        return owningUserID;
    }

    public void setOwningUserID(int value) {
        this.owningUserID = value;
    }

}

