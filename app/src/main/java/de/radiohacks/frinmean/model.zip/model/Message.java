package de.radiohacks.frinmean.model;

import org.simpleframework.xml.Default;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 * Created by thomas on 06.09.14.
 */

/**
 * <p/>
 * Java class for anonymous complex type.
 * <p/>
 * <p/>
 * The following schema fragment specifies the expected content contained
 * within this class.
 * <p/>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MessageTyp" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SendTimestamp" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OwningUser">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="OwningUserName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="OwningUserID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TextMsgID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ImageMsgID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ContactMsgID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="LocationMsgID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="FileMsgID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */

@Root(name = "Message")
public class Message {

    @Element(name = "MessageID", required = true)
    protected int messageID;
    @Element(name = "MessageTyp", required = true)
    protected String messageTyp;
    @Element(name = "SendTimestamp", required = true)
    protected long sendTimestamp;
    @Element(name = "ReadTimestamp", required = true)
    protected long readTimestamp;
    @Element(name = "OwningUser", required = true)
    protected OwningUser owningUser;
    @Element(name = "TextMsgID", required = true)
    protected int textMsgID;
    @Element(name = "ImageMsgID", required = true)
    protected int imageMsgID;
    @Element(name = "ContactMsgID", required = true)
    protected int contactMsgID;
    @Element(name = "LocationMsgID", required = true)
    protected int locationMsgID;
    @Element(name = "FileMsgID", required = true)
    protected int fileMsgID;

    public int getMessageID() {
        return messageID;
    }

    public void setMessageID(int value) {
        this.messageID = value;
    }

    public String getMessageTyp() {
        return messageTyp;
    }

    public void setMessageTyp(String value) {
        this.messageTyp = value;
    }

    public long getSendTimestamp() {
        return sendTimestamp;
    }

    public void setSendTimestamp(long value) {
        this.sendTimestamp = value;
    }

    public long getReadTimestamp() {
        return readTimestamp;
    }

    public void setReadTimestamp(long value) {
        this.readTimestamp = value;
    }

    public OwningUser getOwningUser() {
        return owningUser;
    }

    public void setOwningUser(OwningUser value) {
        this.owningUser = value;
    }

    public int getTextMsgID() {
        return textMsgID;
    }

    public void setTextMsgID(int value) {
        this.textMsgID = value;
    }

    public int getImageMsgID() {
        return imageMsgID;
    }

    public void setImageMsgID(int value) {
        this.imageMsgID = value;
    }

    public int getContactMsgID() {
        return contactMsgID;
    }

    public void setContactMsgID(int value) {
        this.contactMsgID = value;
    }

    public int getLocationMsgID() {
        return locationMsgID;
    }

    public void setLocationMsgID(int value) {
        this.locationMsgID = value;
    }

    public int getFileMsgID() {
        return fileMsgID;
    }

    public void setFileMsgID(int value) {
        this.fileMsgID = value;
    }
}