package de.radiohacks.frinmean.model;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 * <p/>
 * Java class for anonymous complex type.
 * <p/>
 * <p/>
 * The following schema fragment specifies the expected content contained
 * within this class.
 * <p/>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Username" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UserID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Email" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */

/**
 * Created by thomas on 05.09.14.
 */
//@Default(DefaultType.FIELD)
//@Order(elements = {"username", "userID", "email"})
@Root
public class User {

    @Element(name = "Username", required = true)
    protected String username;
    @Element(required = false, name = "UserID")
    protected int userID;
    @Element(name = "Email", required = true)
    protected String email;

    /**
     * Gets the value of the username property.
     *
     * @return possible object is {@link String }
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the value of the username property.
     *
     * @param value allowed object is {@link String }
     */
    public void setUsername(String value) {
        this.username = value;
    }

    /**
     * Gets the value of the userID property.
     */
    public int getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     */
    public void setUserID(int value) {
        this.userID = value;
    }

    /**
     * Gets the value of the email property.
     *
     * @return possible object is {@link String }
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     *
     * @param value allowed object is {@link String }
     */
    public void setEmail(String value) {
        this.email = value;
    }
}